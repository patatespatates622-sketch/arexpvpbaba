package com.targetmod;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

public class ConfigScreen extends Screen {
    private static final String[] ESP = {"Box", "Ring", "Scanner", "Orbit", "Crown", "Diamond"};

    private final List<ButtonWidget> espBtns = new ArrayList<>();
    private final List<ButtonWidget> soundBtns = new ArrayList<>();
    private ButtonWidget espToggle, soundToggle, rainbowToggle, heldToggle;
    private int top;

    public ConfigScreen() {
        super(Text.literal("Target Mod"));
    }

    @Override
    protected void init() {
        espBtns.clear();
        soundBtns.clear();
        Config c = Config.get();

        top = Math.max(34, this.height / 2 - 123);
        int lx = this.width / 2 - 190;
        int rx = this.width / 2 + 10;

        // --- Target ESP paneli ---
        espToggle = addDrawableChild(ButtonWidget.builder(Text.empty(), b -> {
            c.espEnabled = !c.espEnabled;
            refresh();
        }).dimensions(lx, top, 180, 20).build());

        for (int i = 0; i < ESP.length; i++) {
            final int idx = i;
            ButtonWidget btn = ButtonWidget.builder(Text.literal(ESP[i]), b -> {
                c.espMode = idx;
                // Önizleme: kendini 2 sn hedef yap (F5 ile görebilirsin)
                MinecraftClient mc = MinecraftClient.getInstance();
                if (mc.player != null) {
                    TargetMod.target = mc.player;
                    TargetMod.targetExpire = System.currentTimeMillis() + 2000L;
                }
                refresh();
            }).dimensions(lx + (i % 2) * 92, top + 24 + (i / 2) * 22, 88, 20).build();
            espBtns.add(addDrawableChild(btn));
        }

        // --- Hit Sound paneli ---
        soundToggle = addDrawableChild(ButtonWidget.builder(Text.empty(), b -> {
            c.soundEnabled = !c.soundEnabled;
            refresh();
        }).dimensions(rx, top, 180, 20).build());

        for (int i = 0; i < Sounds.NAMES.length; i++) {
            final int idx = i;
            ButtonWidget btn = ButtonWidget.builder(Text.literal(Sounds.NAMES[i]), b -> {
                c.soundMode = idx;
                TargetMod.previewSound();
                refresh();
            }).dimensions(rx + (i % 2) * 92, top + 24 + (i / 2) * 22, 88, 20).build();
            soundBtns.add(addDrawableChild(btn));
        }

        // --- Alt ayarlar ---
        int y1 = top + 140;
        addDrawableChild(new Slider(lx, y1, 180, 20, "Volume", 0.0, 1.0, c.volume, v -> c.volume = v));
        addDrawableChild(new Slider(rx, y1, 180, 20, "Pitch", 0.5, 2.0, c.pitch, v -> c.pitch = v));

        int y2 = top + 164;
        rainbowToggle = addDrawableChild(ButtonWidget.builder(Text.empty(), b -> {
            c.rainbow = !c.rainbow;
            refresh();
        }).dimensions(lx, y2, 180, 20).build());
        addDrawableChild(new Slider(rx, y2, 180, 20, "Color Hue", 0.0, 1.0, c.hue, v -> c.hue = v));

        // --- Held Item (en-boy oranı) paneli ---
        int y3 = top + 202;
        heldToggle = addDrawableChild(ButtonWidget.builder(Text.empty(), b -> {
            c.heldEnabled = !c.heldEnabled;
            refresh();
        }).dimensions(lx, y3, 180, 20).build());
        addDrawableChild(new Slider(rx, y3, 180, 20, "Width", 0.2, 3.0, c.heldWidth, v -> c.heldWidth = v));

        int y4 = top + 226;
        addDrawableChild(new Slider(lx, y4, 180, 20, "Height", 0.2, 3.0, c.heldHeight, v -> c.heldHeight = v));
        addDrawableChild(new Slider(rx, y4, 180, 20, "Depth", 0.2, 3.0, c.heldDepth, v -> c.heldDepth = v));

        int y5 = top + 254;
        addDrawableChild(ButtonWidget.builder(Text.literal("Reset Item Size"), b -> {
            c.heldWidth = 1.0f;
            c.heldHeight = 1.0f;
            c.heldDepth = 1.0f;
            this.clearAndInit();
        }).dimensions(this.width / 2 - 125, y5, 120, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> close())
                .dimensions(this.width / 2 + 5, y5, 120, 20).build());

        refresh();
    }

    private void refresh() {
        Config c = Config.get();
        espToggle.setMessage(Text.literal("Target ESP: " + (c.espEnabled ? "ON" : "OFF"))
                .formatted(c.espEnabled ? Formatting.GREEN : Formatting.RED));
        soundToggle.setMessage(Text.literal("Hit Sound: " + (c.soundEnabled ? "ON" : "OFF"))
                .formatted(c.soundEnabled ? Formatting.GREEN : Formatting.RED));
        heldToggle.setMessage(Text.literal("Held Item Size: " + (c.heldEnabled ? "ON" : "OFF"))
                .formatted(c.heldEnabled ? Formatting.GREEN : Formatting.RED));
        rainbowToggle.setMessage(Text.literal("Rainbow: " + (c.rainbow ? "ON" : "OFF"))
                .formatted(c.rainbow ? Formatting.GREEN : Formatting.RED));

        for (int i = 0; i < espBtns.size(); i++) {
            espBtns.get(i).setMessage(i == c.espMode
                    ? Text.literal("> " + ESP[i]).formatted(Formatting.GREEN)
                    : Text.literal(ESP[i]));
        }
        for (int i = 0; i < soundBtns.size(); i++) {
            soundBtns.get(i).setMessage(i == c.soundMode
                    ? Text.literal("> " + Sounds.NAMES[i]).formatted(Formatting.GREEN)
                    : Text.literal(Sounds.NAMES[i]));
        }
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawCenteredTextWithShadow(this.textRenderer, Text.literal("Target Mod"),
                this.width / 2, top - 28, 0xFFFFFF);
        ctx.drawCenteredTextWithShadow(this.textRenderer, Text.literal("Target ESP"),
                this.width / 2 - 100, top - 12, 0xAAAAAA);
        ctx.drawCenteredTextWithShadow(this.textRenderer, Text.literal("Hit Sound"),
                this.width / 2 + 100, top - 12, 0xAAAAAA);
        ctx.drawCenteredTextWithShadow(this.textRenderer, Text.literal("Held Item Aspect Ratio"),
                this.width / 2, top + 189, 0xAAAAAA);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void removed() {
        Config.save();
    }

    private static class Slider extends SliderWidget {
        private final String label;
        private final double min, max;
        private final Consumer<Float> setter;

        Slider(int x, int y, int w, int h, String label, double min, double max, double cur, Consumer<Float> setter) {
            super(x, y, w, h, Text.empty(), (cur - min) / (max - min));
            this.label = label;
            this.min = min;
            this.max = max;
            this.setter = setter;
            updateMessage();
        }

        @Override
        protected void updateMessage() {
            setMessage(Text.literal(label + ": " + String.format("%.2f", min + this.value * (max - min))));
        }

        @Override
        protected void applyValue() {
            setter.accept((float) (min + this.value * (max - min)));
        }
    }
}
