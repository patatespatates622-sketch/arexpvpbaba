package com.targetmod;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

public class Config {
    public boolean espEnabled = true;
    public int espMode = 0;          // 0..5
    public boolean soundEnabled = true;
    public int soundMode = 0;        // 0..9
    public boolean rainbow = true;
    public float hue = 0.55f;
    public float volume = 1.0f;
    public float pitch = 1.0f;

    // Held item aspect ratio (en-boy oranı)
    public boolean heldEnabled = false;
    public float heldWidth = 1.0f;   // X
    public float heldHeight = 1.0f;  // Y
    public float heldDepth = 1.0f;   // Z

    private static Config inst = new Config();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("targetmod.json");
    }

    public static Config get() {
        return inst;
    }

    public static void load() {
        try {
            Path p = path();
            if (Files.exists(p)) {
                Config c = GSON.fromJson(Files.readString(p), Config.class);
                if (c != null) {
                    inst = c;
                }
            }
        } catch (Exception ignored) {
        }
        inst.espMode = Math.max(0, Math.min(5, inst.espMode));
        inst.soundMode = Math.max(0, Math.min(9, inst.soundMode));
        inst.heldWidth = clampScale(inst.heldWidth);
        inst.heldHeight = clampScale(inst.heldHeight);
        inst.heldDepth = clampScale(inst.heldDepth);
    }

    private static float clampScale(float v) {
        return Float.isNaN(v) ? 1.0f : Math.max(0.2f, Math.min(3.0f, v));
    }

    public static void save() {
        try {
            Files.writeString(path(), GSON.toJson(inst));
        } catch (Exception ignored) {
        }
    }
}
