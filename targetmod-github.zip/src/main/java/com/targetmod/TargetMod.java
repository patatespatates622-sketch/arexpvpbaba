package com.targetmod;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.ActionResult;
import org.lwjgl.glfw.GLFW;

public class TargetMod implements ClientModInitializer {
    public static LivingEntity target;
    public static long targetExpire;

    private static KeyBinding openKey;

    @Override
    public void onInitializeClient() {
        Config.load();

        openKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.targetmod.open",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_O,
                "category.targetmod"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openKey.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(new ConfigScreen());
                }
            }
        });

        AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (world.isClient() && player == mc.player
                    && entity instanceof LivingEntity living && living.isAlive()) {
                target = living;
                targetExpire = System.currentTimeMillis() + 3000L;
                playHitSound();
            }
            return ActionResult.PASS;
        });

        WorldRenderEvents.AFTER_TRANSLUCENT.register(EspRenderer::render);
    }

    public static void playHitSound() {
        Config c = Config.get();
        if (!c.soundEnabled) return;
        MinecraftClient.getInstance().getSoundManager().play(
                PositionedSoundInstance.master(Sounds.get(c.soundMode), c.pitch, c.volume));
    }

    public static void previewSound() {
        MinecraftClient.getInstance().getSoundManager().play(
                PositionedSoundInstance.master(Sounds.get(Config.get().soundMode),
                        Config.get().pitch, Config.get().volume));
    }
}
