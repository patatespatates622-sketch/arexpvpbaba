package com.targetmod;

import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;

public final class Sounds {
    public static final String[] NAMES = {
            "Classic", "Crit", "XP Orb", "Bell", "Anvil",
            "Pop", "Arrow Hit", "Glass", "Level Up", "Chime"
    };

    private Sounds() {}

    public static SoundEvent get(int i) {
        return switch (i) {
            case 0 -> SoundEvents.ENTITY_PLAYER_ATTACK_STRONG;
            case 1 -> SoundEvents.ENTITY_PLAYER_ATTACK_CRIT;
            case 2 -> SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP;
            case 3 -> SoundEvents.BLOCK_BELL_USE;
            case 4 -> SoundEvents.BLOCK_ANVIL_LAND;
            case 5 -> SoundEvents.ENTITY_ITEM_PICKUP;
            case 6 -> SoundEvents.ENTITY_ARROW_HIT_PLAYER;
            case 7 -> SoundEvents.BLOCK_GLASS_BREAK;
            case 8 -> SoundEvents.ENTITY_PLAYER_LEVELUP;
            default -> SoundEvents.BLOCK_AMETHYST_BLOCK_CHIME;
        };
    }
}
