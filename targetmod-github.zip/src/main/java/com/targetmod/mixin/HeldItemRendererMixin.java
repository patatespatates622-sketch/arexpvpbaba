package com.targetmod.mixin;

import com.targetmod.Config;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ModelTransformationMode;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Oyuncunun elindeki eşyanın (1. ve 3. şahıs) genişlik / yükseklik / derinlik
 * oranını ayarlar. Her zaman push/pop çiftleri dengeli tutulur.
 */
@Mixin(HeldItemRenderer.class)
public class HeldItemRendererMixin {

    @Inject(method = "renderItem", at = @At("HEAD"))
    private void targetmod$scaleStart(LivingEntity entity, ItemStack stack, ModelTransformationMode mode,
                                      boolean leftHanded, MatrixStack matrices,
                                      VertexConsumerProvider vertexConsumers, int light, CallbackInfo ci) {
        matrices.push();
        Config c = Config.get();
        if (c.heldEnabled && entity == MinecraftClient.getInstance().player) {
            matrices.scale(c.heldWidth, c.heldHeight, c.heldDepth);
        }
    }

    @Inject(method = "renderItem", at = @At("RETURN"))
    private void targetmod$scaleEnd(LivingEntity entity, ItemStack stack, ModelTransformationMode mode,
                                    boolean leftHanded, MatrixStack matrices,
                                    VertexConsumerProvider vertexConsumers, int light, CallbackInfo ci) {
        matrices.pop();
    }
}
