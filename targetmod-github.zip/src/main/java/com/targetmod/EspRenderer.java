package com.targetmod;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public final class EspRenderer {
    private static final double TAU = Math.PI * 2.0;

    private EspRenderer() {}

    private static final class Ctx {
        MatrixStack.Entry e;
        VertexConsumer vc;
        float r, g, b;
    }

    public static void render(WorldRenderContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        Config cfg = Config.get();
        if (!cfg.espEnabled || mc.player == null) return;

        LivingEntity t = TargetMod.target;
        if (t == null) return;

        long now = System.currentTimeMillis();
        long left = TargetMod.targetExpire - now;
        if (left <= 0 || !t.isAlive() || t.isRemoved()) {
            TargetMod.target = null;
            return;
        }

        MatrixStack ms = ctx.matrixStack();
        VertexConsumerProvider vcp = ctx.consumers();
        if (ms == null || vcp == null) return;

        float alpha = Math.min(1f, left / 600f);
        float td = ctx.tickCounter().getTickDelta(false);
        Vec3d cam = ctx.camera().getPos();
        Vec3d p = t.getLerpedPos(td);
        double sec = (now % 1_000_000L) / 1000.0;

        int rgb = cfg.rainbow
                ? MathHelper.hsvToRgb((float) ((sec * 0.15) % 1.0), 0.8f, 1f)
                : MathHelper.hsvToRgb(cfg.hue, 0.85f, 1f);

        Ctx c = new Ctx();
        c.r = (rgb >> 16 & 255) / 255f;
        c.g = (rgb >> 8 & 255) / 255f;
        c.b = (rgb & 255) / 255f;
        if (t.hurtTime > 0) { // vurulunca kırmızıya döner
            c.r = 1f; c.g = 0.2f; c.b = 0.2f;
        }

        ms.push();
        ms.translate(p.x - cam.x, p.y - cam.y, p.z - cam.z);
        c.e = ms.peek();
        c.vc = vcp.getBuffer(RenderLayer.getLines());

        double w = t.getWidth() / 2.0;
        double h = t.getHeight();

        switch (cfg.espMode) {
            case 0 -> box(c, w + 0.05, h + 0.05, alpha);
            case 1 -> ring1(c, w, alpha, sec);
            case 2 -> scanner(c, w, h, alpha, sec);
            case 3 -> orbit(c, w, h, alpha, sec);
            case 4 -> crown(c, h, alpha, sec);
            default -> diamond(c, h, alpha, sec);
        }

        ms.pop();
    }

    // ---------- Modes ----------

    /** 0: Box */
    private static void box(Ctx c, double w, double h, float a) {
        double y0 = -0.05;
        double[][] v = {
                {-w, y0, -w}, {w, y0, -w}, {w, y0, w}, {-w, y0, w},
                {-w, h, -w}, {w, h, -w}, {w, h, w}, {-w, h, w}
        };
        int[][] edges = {
                {0, 1}, {1, 2}, {2, 3}, {3, 0},
                {4, 5}, {5, 6}, {6, 7}, {7, 4},
                {0, 4}, {1, 5}, {2, 6}, {3, 7}
        };
        for (int[] ed : edges) {
            double[] p1 = v[ed[0]], p2 = v[ed[1]];
            line(c, p1[0], p1[1], p1[2], p2[0], p2[1], p2[2], a);
        }
    }

    /** 1: Ring (ayakta nabız gibi atan halka) */
    private static void ring1(Ctx c, double w, float a, double sec) {
        double r = w + 0.35 + 0.05 * Math.sin(sec * 4);
        ring(c, r, 0.03, 0, 48, a);
        ring(c, r - 0.08, 0.03, 0, 48, a * 0.6f);
    }

    /** 2: Scanner (yukarı aşağı gezen halka + iz) */
    private static void scanner(Ctx c, double w, double h, float a, double sec) {
        for (int k = 0; k < 6; k++) {
            double phase = sec * 1.8 - k * 0.12;
            double y = h * (0.5 + 0.5 * Math.sin(phase));
            ring(c, w + 0.2, y, 0, 40, a * (1f - k / 6f));
        }
    }

    /** 3: Orbit (etrafında dönen 3 kuyruklu nokta) */
    private static void orbit(Ctx c, double w, double h, float a, double sec) {
        double r = w + 0.4;
        for (int i = 0; i < 3; i++) {
            double base = sec * 2.5 + i * TAU / 3.0;
            double px = 0, py = 0, pz = 0;
            for (int k = 0; k < 12; k++) {
                double ang = base - k * 0.10;
                double x = Math.cos(ang) * r;
                double z = Math.sin(ang) * r;
                double y = h * (0.5 + 0.35 * Math.sin(ang * 1.5 + i));
                if (k > 0) {
                    line(c, px, py, pz, x, y, z, a * (1f - k / 12f));
                } else {
                    cross(c, x, y, z, 0.08, a);
                }
                px = x; py = y; pz = z;
            }
        }
    }

    /** 4: Crown (kafanın üstünde dönen taç) */
    private static void crown(Ctx c, double h, float a, double sec) {
        double y = h + 0.15;
        double rot = sec * 1.5;
        double r = 0.35;
        ring(c, r, y, rot, 24, a);
        for (int i = 0; i < 8; i++) {
            double ang = rot + i * TAU / 8.0;
            double x = Math.cos(ang) * r;
            double z = Math.sin(ang) * r;
            line(c, x, y, z, x, y + 0.3, z, a);
        }
    }

    /** 5: Diamond (kafanın üstünde dönen elmas) */
    private static void diamond(Ctx c, double h, float a, double sec) {
        double cy = h + 0.55 + 0.08 * Math.sin(sec * 3);
        double rot = sec * 2.0;
        double rr = 0.2, hh = 0.3;
        double[][] eq = new double[4][];
        for (int i = 0; i < 4; i++) {
            double ang = rot + i * Math.PI / 2.0;
            eq[i] = new double[]{Math.cos(ang) * rr, cy, Math.sin(ang) * rr};
        }
        for (int i = 0; i < 4; i++) {
            double[] p1 = eq[i], p2 = eq[(i + 1) % 4];
            line(c, p1[0], p1[1], p1[2], p2[0], p2[1], p2[2], a);
            line(c, 0, cy + hh, 0, p1[0], p1[1], p1[2], a);
            line(c, 0, cy - hh, 0, p1[0], p1[1], p1[2], a);
        }
    }

    // ---------- Helpers ----------

    private static void ring(Ctx c, double radius, double y, double rot, int segs, float a) {
        double px = Math.cos(rot) * radius, pz = Math.sin(rot) * radius;
        for (int i = 1; i <= segs; i++) {
            double ang = rot + i * TAU / segs;
            double x = Math.cos(ang) * radius, z = Math.sin(ang) * radius;
            line(c, px, y, pz, x, y, z, a);
            px = x; pz = z;
        }
    }

    private static void cross(Ctx c, double x, double y, double z, double s, float a) {
        line(c, x - s, y, z, x + s, y, z, a);
        line(c, x, y - s, z, x, y + s, z, a);
        line(c, x, y, z - s, x, y, z + s, a);
    }

    private static void line(Ctx c, double x1, double y1, double z1,
                             double x2, double y2, double z2, float a) {
        float dx = (float) (x2 - x1), dy = (float) (y2 - y1), dz = (float) (z2 - z1);
        float len = MathHelper.sqrt(dx * dx + dy * dy + dz * dz);
        if (len < 1.0E-6f) return;
        dx /= len; dy /= len; dz /= len;
        c.vc.vertex(c.e, (float) x1, (float) y1, (float) z1).color(c.r, c.g, c.b, a).normal(c.e, dx, dy, dz);
        c.vc.vertex(c.e, (float) x2, (float) y2, (float) z2).color(c.r, c.g, c.b, a).normal(c.e, dx, dy, dz);
    }
}
